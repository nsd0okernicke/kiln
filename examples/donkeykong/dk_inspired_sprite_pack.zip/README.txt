DK-Inspired Sprite Pack (original pixel art)
============================================

Original 8-bit style assets inspired by classic arcade climbing games.
These are NEW designs (different palette, costume colors, ape with no
necktie/emblem, damsel with ponytail + lavender dress) so they can be
used as placeholders / original game art.

Folder layout
-------------
boards/     224x256 stage backgrounds (25m, 50m, 75m, 100m)
sprites/    characters, enemies, items (transparent PNG)
tiles/      repeating girder / ladder / rivet / pipe tiles

Palette notes
-------------
- Girders: coral-red  (#D6565C) instead of classic hot-pink
- 100m girders: steel blue
- Ladders: aqua (#40D2C4)
- Hero: rusty-orange cap, indigo overalls, cream shirt
- Ape: chocolate fur, no tie
- Damsel: auburn ponytail, lavender dress

Filenames match the requested list.
